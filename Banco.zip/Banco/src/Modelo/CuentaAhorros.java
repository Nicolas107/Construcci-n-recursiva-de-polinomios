/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Nicolas
 */
public class CuentaAhorros extends Cuenta{
    private int clave;
    
    public CuentaAhorros(){
        clave = 1234;
    }
    
    @Override
    public void retirar(long valor) {
        this.saldo = saldo - valor;
    }

    @Override
    public void consignar(long valor) {
        this.saldo = saldo + valor;
    }
}
