/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Vista.*;
import Modelo.*;
import java.awt.event.*;

/**
 *
 * @author Nicolas
 */
public class Control implements ActionListener{
    Formulario frmPrincipal;
    FormularioConsignar frmConsignar;
    FormularioConsultar frmConsultar;
    FormularioRetirar frmRetirar;
    Cliente objCliente;
    
    public void iniciar(){
        frmPrincipal.setVisible(true);
    }

    public Control() {
        frmPrincipal = new Formulario();
        frmConsignar = new FormularioConsignar();
        frmConsultar = new FormularioConsultar();
        frmRetirar = new FormularioRetirar();
        objCliente = new Cliente();
        objCliente.setNombre("Nicolas");
        frmPrincipal.getEscritorio().add(frmConsignar);
        frmPrincipal.getEscritorio().add(frmRetirar);
        frmPrincipal.getEscritorio().add(frmConsultar);
        frmPrincipal.getMenuIConsignar().addActionListener(this);
        frmPrincipal.getMenuIRetirar().addActionListener(this);
        frmPrincipal.getMenuIConsultar().addActionListener(this);
        frmConsignar.getBtnConsignar().addActionListener(this);
        frmConsignar.getBtnCancelar().addActionListener(this);
        frmRetirar.getBtnRetirar().addActionListener(this);
        frmRetirar.getBtnCancelar().addActionListener(this);
        frmConsultar.getBtnCerrar().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==frmPrincipal.getMenuIConsignar()){
            frmConsignar.setVisible(true);
        }
        if(e.getSource()==frmPrincipal.getMenuIConsignar()){
            frmRetirar.setVisible(true);
        }
        if(e.getSource()==frmConsignar.getBtnConsignar()){
            objCliente.getObjCuenta().consignar(Long.parseLong(frmConsignar.getTxtValorConsignar().getText()));
        }
    }
    
    
}
